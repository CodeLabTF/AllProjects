from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.





def index(response, id):
    return render(response, "home.html")

def home(response):
    return render(response, "base/home.html")

def services(response):
    return render(response, "services/services.html")
